//
//  MerculetEncrypteHelper.h
//  MerculetEncrypte
//
//  Created by 王大吉 on 14/5/2018.
//  Copyright © 2018 王大吉. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MerculetEncrypteHelper : NSObject

+ (NSString *)generateString:(NSString *)sourceString;

@end
